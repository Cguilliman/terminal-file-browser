go get github.com/gizak/termui
echo "termui - installed"
go get github.com/gizak/termui/widgets
echo "termui/widgets - installed"
# go get github.com/nsf/termbox-go
# echo "termbox-go - installed"